import java.io.*;
import java.net.*;
import java.util.Scanner;

public class server {
    public static void main(String[] args){
        ServerSocket ss=null;
        Socket s=null;
         try{
              ss=new ServerSocket(8888);
         }catch(IOException e1){
             System.out.println("出现异常:"+e1);
         }
         System.out.println("服务端已启动，等待客户端连接...");
         try{
             s=ss.accept();
         }catch(IOException e2){
             System.out.println("出现异常:"+e2);
         }
         System.out.println("客户端已连接");
         System.out.println("发送文件请按1,接收文件请按2，结束请按3");
         int k;
         for(k=1;k>0;k++) {
             int j;
             Scanner scan = new Scanner(System.in);
             j = scan.nextInt();
             switch (j) {
                 case 1:
                     int u,v=0;
                     for(u=1;u>0;u++) {
                         if(v==5){
                             u=-1;
                         }else {
                             Socket n=null;
                             try {
                                 System.out.println("请先确保接收方已按2");
                                 n = ss.accept();
                                 DataOutputStream dis = new DataOutputStream(n.getOutputStream());
                                 System.out.println("请输入将被发送的文件的路径:");
                                 Scanner scanner = new Scanner(System.in);
                                 File f = new File(scanner.nextLine());
                                 System.out.println("开始传输文件");
                                 FileInputStream fis = new FileInputStream(f);
                                 dis.writeUTF(f.getName());
                                 dis.writeLong(f.length());
                                 byte[] container = new byte[5125];
                                 int i = 0;
                                 while ((i = fis.read(container)) >= 0) {
                                     dis.write(container, 0, i);
                                 }
                                 n.close();
                                 fis.close();
                             }catch(FileNotFoundException e3){
                                 System.out.println("出现异常：找不该到文件");
                             }catch(IOException e4){
                                 System.out.println("出现异常:"+e4);
                             }
                             System.out.println("传输完成");
                             System.out.println("结束发送请按5，继续发送请按1");
                             v=scan.nextInt();
                         }
                     }
                     System.out.println("已退出发送状态，请继续操作(发送文件请按1，接收文件请按2，结束请按3)");
                     break;
                 case 2:
                     int t,h=0;
                     for(t=1;t>0;t++) {
                         if(h==5){
                             t=-1;
                         }else {
                             System.out.println("正在等待客户端发送文件...");
                             Socket c=null;
                             long cd;
                             String filename;
                             try {
                                 c= ss.accept();
                                 DataInputStream is = new DataInputStream(c.getInputStream());
                                 filename = is.readUTF();
                                 long w = is.readLong();
                                 if (w % 1024 != 0) {
                                     cd = w / 1024 + 1;
                                 } else if (w == 0) {
                                     cd = 0;
                                 } else {
                                     cd = w / 1024;
                                 }
                                 FileOutputStream os = new FileOutputStream("D:/" + filename);
                                 byte[] buffer = new byte[5125];
                                 int cnt = 0;
                                 while ((cnt = is.read(buffer)) >= 0) {
                                     os.write(buffer, 0, cnt);
                                 }
                                 os.close();
                                 c.close();
                                 System.out.println("接收到文件:" + filename + "   大小:" + cd + "KB  (已保存到D盘下)");
                             }catch(IOException e5){
                                 System.out.println("出现异常:"+e5);
                             }
                             System.out.println("结束接收请按5,继续接收请按2");
                             h = scan.nextInt();
                         }
                     }
                     System.out.println("已退出接收状态，请继续操作(发送文件请按1，接收文件请按2，结束请按3)");
                     break;
                 case 3:k=-1;
                     try{
                         s.close();
                     }catch(IOException e6){
                         System.out.println("出现异常:"+e6);
                     }
                     System.out.println("已与客户端断开连接");
                      break;
             }
         }
     }
}
