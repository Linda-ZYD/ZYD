import java.net.*;
import java.io.*;
import java.util.Scanner;

public class client {
    public static void main(String[] args){
        System.out.println("请输入您的主机IP地址:");
        Scanner scanner=new Scanner(System.in);
        String ip=scanner.nextLine();
        Socket s=null;
        try{
            s=new Socket(ip,8888);
        }catch(IOException e1){
            System.out.println("出现异常:"+e1);
        }
        System.out.println("已连接服务端");
        System.out.println("发送文件请按1，接收文件请按2，结束请按3");
        Scanner scan=new Scanner(System.in);
        int j,k;
        for(k=1;k>0;k++) {
            j=scan.nextInt();
            switch (j) {
                case 1:
                    int t,h=0;
                    for(t=1;t>0;t++) {
                       if(h==5){
                           t=-1;
                       }else {
                           Socket n =null;
                          try {
                              n=new Socket(ip, 8888);
                              DataOutputStream is = new DataOutputStream(n.getOutputStream());
                              System.out.println("在确保服务端已按2后，输入将被发送的文件的路径");
                              File f = new File(scanner.nextLine());
                              System.out.println("开始传输文件");
                              FileInputStream fis = new FileInputStream(f);
                              byte[] buffer = new byte[5125];
                              int cnt = 0;
                              is.writeUTF(f.getName());
                              is.writeLong(f.length());
                              while ((cnt = fis.read(buffer)) >= 0) {
                                  is.write(buffer, 0, cnt);
                              }
                              fis.close();
                              n.close();
                          }catch(FileNotFoundException e2){
                              System.out.println("出现异常：找不到该文件");
                          }catch(IOException e3){
                              System.out.println("出现异常:"+e3);
                          }
                           System.out.println("传输完成");
                           System.out.println("结束发送请按5，继续发送请按1");
                       //    System.out.println("(注意：继续发送前请先确保接收方继续接收)");
                           h=scan.nextInt();
                       }
                    }
                    System.out.println("已退出发送状态，请继续操作(发送文件请按1，接收文件请按2，结束请按3)");
                    break;
                case 2:
                    int u,v=0;
                    for(u=1;u>0;u++) {
                        if(v==5){
                            u=-1;
                        }else {
                            System.out.println("正在等待服务端发送文件...");
                            Socket ss =null;
                            try {
                                ss = new Socket(ip, 8888);
                                DataInputStream dis = new DataInputStream(ss.getInputStream());
                                String filename = dis.readUTF();
                                long w = dis.readLong();
                                long dx;
                                if (w % 1024 != 0) {
                                    dx = w / 1024 + 1;
                                } else if (w == 0) {
                                    dx = 0;
                                } else {
                                    dx = w / 1024;
                                }
                                FileOutputStream os = new FileOutputStream("E:/" + filename);
                                byte[] container = new byte[5125];
                                int i = 0;
                                while ((i = dis.read(container)) >= 0) {
                                    os.write(container, 0, i);
                                }
                                os.close();
                                ss.close();
                                System.out.println("接收到文件:" + filename + "   大小:" + dx + "KB  (已保存到E盘下)");
                            }catch(IOException e4){
                                System.out.println("出现异常:"+e4);
                            }
                            System.out.println("结束接收请按5，继续接收请按2");
                            v=scan.nextInt();
                        }
                    }
                    System.out.println("已退出接收状态，请继续操作(发送文件请按1，接收文件请按2，结束请按3)");
                    break;
                case 3:
                    k = -1;
                    try{
                        s.close();
                    }catch(IOException e5){
                        System.out.println("出现异常:"+e5);
                    }
                    System.out.println("已与服务端断开连接");
                    break;
            }

        }
    }
}


