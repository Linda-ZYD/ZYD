#ifndef _FOUR_H_
#define _FOUR_H_

typedef enum Status
{
    ERROR = 0,OK = 1
}Status;

typedef int ElemType;

typedef struct SqStack{
       ElemType	*elem;
       int top;
       int size;
}SqStack;

Status initStack(SqStack *s,int sizes);
void pushStack(SqStack *s,ElemType z);
ElemType popStack(SqStack *s,ElemType *z);
ElemType getTopStack(SqStack *s,ElemType *z);
int tell(char x);
int trans_to_num(char x);
char trans_to_char(int x);
int count(SqStack *s,SqStack *t);
int calculate(int x,int y,char z);

#endif

