#include<stdio.h>
#include<stdlib.h>
#include"Four.h"

Status initStack(SqStack *s,int sizes)  //��ʼ������
{
   s->elem=(ElemType *)malloc(sizes*sizeof(ElemType));
   if(s->elem==NULL)
     return ERROR;
   s->top=-1;
   s->size=sizes;
   return OK;
}


void pushStack(SqStack *s,ElemType z)  //��ջ
{
    if(s->top>=100)
        printf("ջ��\n");
    s->top++;
    s->elem[s->top]=z;
}

ElemType popStack(SqStack *s,ElemType *z)   //��ջ
{
    if(s->top==-1)
        {
         *z=0;
         return *z;
         }
   *z=s->elem[s->top];
   s->top--;
   return *z;
}

ElemType getTopStack(SqStack *s,ElemType *z)   //�õ�����ͷԪ��
{
    if(s->top==-1)
       {
        *z=0;
        return *z;
        }
  *z=s->elem[s->top];
  return *z;
}


int tell(char x)     //ʶ�������
{
    int i;
    switch(x){
        case '+':i=0;break;
        case '-':i=1;break;
        case '*':i=2;break;
        case '/':i=3;break;
        case '(':i=4;break;
        case ')':i=5;break;
    }
    return i;
}


int trans_to_num(char x)   //�ַ���ת����
{
    int i;
    i=x-'0';
    return i;
}


char trans_to_char(int x)   //����ת�ַ���
{
    char s;
    s=x+'0';
    return s;
}

int count(SqStack *s,SqStack *t)   //������
{
    int temp=0;
    ElemType n,c;
    while(temp<=s->top)
    {
        ElemType k=s->elem[temp];
        if(k!=-5&&k!=-3&&k!=-6&&k!=-1)
        {
            pushStack(t,k);
        }else{
               int x,y,z;
               x=popStack(t,&n);
               y=popStack(t,&n);
               z=calculate(x,y,trans_to_char(k));
               pushStack(t,z);
        }
        temp++;
    }
    c=t->elem[t->top];
    return c;
}


int calculate(int x,int y,char z)  //����
{
    int i;
    switch(z)
    {
        case '+':i=y+x;break;
        case '-':i=y-x;break;
        case '*':i=y*x;break;
        case '/':i=y/x;break;
    }
    return i;
}

