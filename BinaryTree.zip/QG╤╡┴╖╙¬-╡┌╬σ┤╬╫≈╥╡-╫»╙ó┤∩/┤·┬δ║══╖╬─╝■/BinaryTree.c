#include <stdio.h>
#include "BinaryTree.h"
#include <stdlib.h>
#include <string.h>

Status InitBiTree(BiTree T) //����ն�����T
{
    T=NULL;
    return SUCCESS;
}


Status DestroyBiTree(BiTree T) //�ݻٶ�����T
{
    if(T)
    {
        DestroyBiTree(T->lchild);
        DestroyBiTree(T->rchild);
        free(T);
    }
    return SUCCESS;
}


Status CreateTreeAndValueIt(BiTree T,char *definition) //��definition���������T����������ͼ�����
{
     int i=0,top=-1,k=1;
     BiTree p,s[100];
     char ch;
     while(definition[i]!='\0')
     {
         ch=definition[i];
         if(ch=='+'||ch=='-'||ch=='*'||ch=='/')
         {
             p=(BiTNode *)malloc(sizeof(BiTNode));
             p->data=ch;
             p->lchild=p->rchild=NULL;
             top++;
             s[top]=p;
             if(T==NULL)
             {
                 T=p;
             }
             else
             {
                switch(k)
                {
                    case 1:s[top-1]->lchild=p;k=2;break;
                    case 2:s[top-1]->rchild=p;k=1;break;
                }
             }
         }
         else
         {
             p=(BiTNode *)malloc(sizeof(BiTNode));
             p->data=ch;
             p->lchild=p->rchild=NULL;
             switch(k)
             {
                 case 1:s[top]->lchild=p;k=2;break;
                 case 2:s[top]->rchild=p;k=1;break;
             }
         }
         i++;
     }
    printf("�������:");
    PreOrderTraverse(T);
    printf("\n");
    printf("�������:");
    InOrderTraverse(T);
    printf("\n");
    printf("�������:");
    PostOrderTraverse(T);
    printf("\n");
    printf("�������:");
    LevelOrderTraverse(T);
    printf("\n");
    SqStack *S;
    S=(SqStack *)malloc(sizeof(SqStack));
    initStack(S,50);
    Value(T,S);
    int result=getTopStack(S);
    printf("��������:%d\n",result);
    DestroyBiTree(T);
    destoryStack(S);
     return SUCCESS;
}

Status PreOrderTraverse(BiTree T) //�������
{
    if(T)
    {
        printf("%c ",T->data);
        PreOrderTraverse(T->lchild);
        PreOrderTraverse(T->rchild);
    }
    return SUCCESS;
}


Status InOrderTraverse(BiTree T)	//�������
{
    if(T)
    {
        InOrderTraverse(T->lchild);
        printf("%c ",T->data);
        InOrderTraverse(T->rchild);
    }
    return SUCCESS;
}


Status PostOrderTraverse(BiTree T) //�������
{
    if(T)
    {
        PostOrderTraverse(T->lchild);
        PostOrderTraverse(T->rchild);
        printf("%c ",T->data);
    }
    return SUCCESS;
}


Status LevelOrderTraverse(BiTree T)//�������
{
   LQueue *Q=(LQueue *)malloc(sizeof(LQueue));
   InitLQueue(Q);
   if(T==NULL) return ERROR;
   EnLQueue(Q,T);
   printf("%c ",T->data);
   if(T->lchild)  EnLQueue(Q,T->lchild);
   if(T->rchild)  EnLQueue(Q,T->rchild);
   while(Q->front!=Q->rear)
   {
       T=DeLQueue(Q,T);
       if(T)
       {
           printf("%c ",T->data);
           if(T->lchild) EnLQueue(Q,T->lchild);
           if(T->rchild) EnLQueue(Q,T->rchild);
       }
   }
   DestoryLQueue(Q);
   return SUCCESS;
}


void Value(BiTree T,SqStack *S) //������Ķ�������ֵ
{
  if(T==NULL)
  {
    return;
  }
  else
  {
      Value(T->lchild,S);
      Value(T->rchild,S);
      if(T->data!='+'&&T->data!='-'&&T->data!='*'&&T->data!='/')
      {
          int n=T->data-'0';
          pushStack(S,n);
      }
      else
      {
          int x=popStack(S);
          int y=popStack(S);
          int sum=0;
          if(T->data=='+') sum=y+x;
          if(T->data=='-') sum=y-x;
          if(T->data=='*') sum=y*x;
          if(T->data=='/') sum=y/x;
          pushStack(S,sum);
      }
  }
}


void InitLQueue(LQueue *Q)  //��ʼ��������
{
    Node *head=(Node *)malloc(sizeof(Node));
    Q->front=head;
    Q->rear=head;
    head->next=NULL;
    Q->data_size=0;
}


Status EnLQueue(LQueue *Q, BiTree T)  //���������
{
    Node *p=(Node *)malloc(sizeof(Node));
    if(p==NULL)
        return ERROR;
    p->data=T;
    p->next=NULL;
    if(Q->front->next==NULL&&Q->rear==NULL)
        Q->front->next=Q->rear=p;
    else
    {
     Q->rear->next=p;
     Q->rear=p;
    }
    return SUCCESS;
}


BiTree DeLQueue(LQueue *Q,BiTree T)  //�����г���
{
    Node *p;
  if(Q->front==Q->rear)
     return NULL;
  else
     {
         p=(Node *)malloc(sizeof(Node));
         p=Q->front->next;
         Q->front->next=p->next;
         if(p==Q->rear)
            Q->rear=Q->front;
         free(p);
         if(Q->front->next!=NULL)
           return Q->front->next->data;
         else return NULL;
     }
}


void DestoryLQueue(LQueue *Q)  //����������
{
    while(Q->front!=Q->rear)
    {
        Node *p=(Node *)malloc(sizeof(Node));
        p=Q->front->next;
        Q->front=p->next;
        if(p==Q->rear)
            Q->front=Q->rear;
        free(p);
    }
    Q->front=NULL;
    Q->rear=NULL;
}


Status initStack(SqStack *s,int sizes)  //��ʼ��ջ
{
   s->elem=(ElemType *)malloc(sizes*sizeof(ElemType));
   if(s->elem==NULL)
     return ERROR;
   s->top=-1;
   s->size=sizes;
   return SUCCESS;
}


void pushStack(SqStack *s,ElemType z)  //��ջ
{
    if(s->top>=100)
        printf("ջ��\n");
    s->top++;
    s->elem[s->top]=z;
}

ElemType popStack(SqStack *s)   //��ջ
{
    int e;
    if(s->top==-1)
        {
         return 0;
         }
   e=s->elem[s->top];
   s->top--;
   return e;
}

ElemType getTopStack(SqStack *s)   //�õ�����ͷԪ��
{
    if(s->top==-1)
       {
        return 0;
        }
  return s->elem[s->top];
}


Status destoryStack(SqStack *s)  //����ջ
{
   if(s==NULL)
      return ERROR;
   free(s->elem);
   return SUCCESS;
}
