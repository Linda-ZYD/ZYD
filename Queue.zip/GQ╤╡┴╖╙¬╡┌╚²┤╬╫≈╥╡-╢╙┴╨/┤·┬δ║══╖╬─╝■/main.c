#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main()
{
    int length;
    void *r,*s=(void *)malloc(sizeof(void));
    void (*foo)(void *q,int a);
    int a[30]; double b[30]; char c[50],d;
    int i,j,k=0;
    char x,z,y;
    AQueue *p=(AQueue *)malloc(sizeof(AQueue));
    LQueue *Q=(LQueue *)malloc(sizeof(LQueue));
    printf("��ѡ��洢��ʽ:ѭ������:A   ������:B\n");
    scanf("%c",&x);
    switch(x)
    {
        case 'A':InitAQueue(p);
                 printf("�ѳ�ʼ��һ��ѭ������\n");
                 printf("����ȷ�����������ݵ�����:\n");
                 printf("int:1  double:2  char:3\n");
                 scanf("%d",&j);
                 switch(j)
                 {
                     case 1:printf("��ѡ�����:\n");
                            printf("�п�:A   ��:B   ���:C   ���ٲ�����:D\n");
                            printf("��ͷ����:E,   ��������ӡ:F    ���:G  �鿴��ͷ:H\n");
                            for(i=1;i>0;i++)
                           {
                              scanf("%c",&z);
                              switch(z)
                              {
                                 case 'A':IsEmptyAQueue(p);break;
                                 case 'B':length=LengthAQueue(p);
                                          printf("��ǰ����Ϊ:%d\n",length);break;
                                 case 'C':printf("������Ҫ��ӵ�����:");
                                          scanf("%d",&a[k]); r=&a[k];
                                          EnAQueue(p,r);
                                          printf("��ӳɹ�!\n");k++;break;
                                 case 'D':DestoryAQueue(p);
                                          i=-1;break;
                                 case 'E':DeAQueue(p);
                                          printf("���ӳɹ�!\n");break;
                                 case 'F':foo=APrint;
                                          TraverseAQueue(p,foo,j);break;
                                 case 'G':ClearAQueue(p);
                                          printf("��ճɹ�!\n");break;
                                 case 'H':GetHeadAQueue(p,s,j);break;
                              }
                           }break;
                     case 2:printf("��ѡ�����:\n");
                            printf("�п�:A   ��:B   ���:C   ���ٲ�����:D\n");
                            printf("��ͷ����:E,   ��������ӡ:F    ���:G  �鿴��ͷ:H\n");
                            for(i=1;i>0;i++)
                           {
                              scanf("%c",&z);
                              switch(z)
                              {
                                 case 'A':IsEmptyAQueue(p);break;
                                 case 'B':length=LengthAQueue(p);
                                          printf("��ǰ����Ϊ:%d\n",length);break;
                                 case 'C':printf("������Ҫ��ӵ�С��:");
                                          scanf("%lf",&b[k]); r=&b[k];
                                          EnAQueue(p,r);
                                          printf("��ӳɹ�!\n");k++;break;
                                 case 'D':DestoryAQueue(p);
                                          i=-1;break;
                                 case 'E':DeAQueue(p);
                                          printf("���ӳɹ�!\n");break;
                                 case 'F':foo=APrint;
                                          TraverseAQueue(p,foo,j);break;
                                 case 'G':ClearAQueue(p);
                                          printf("��ճɹ�!\n");break;
                                 case 'H':GetHeadAQueue(p,s,j);break;
                              }
                           }break;
                     case 3:printf("��ѡ�����:\n");
                            printf("�п�:A   ��:B   ���:C   ���ٲ�����:D\n");
                            printf("��ͷ����:E,   ��������ӡ:F    ���:G  �鿴��ͷ:H\n");
                            for(i=1;i>0;i++)
                           {
                              scanf("%c",&z);
                              switch(z)
                              {
                                 case 'A':IsEmptyAQueue(p);break;
                                 case 'B':length=LengthAQueue(p);
                                          printf("��ǰ����Ϊ:%d\n",length);break;
                                 case 'C':printf("������Ҫ��ӵ��ַ�:");
                                          scanf("%c",&d);
                                          scanf("%c",&c[k]); r=&c[k];
                                          EnAQueue(p,r);
                                          printf("��ӳɹ�!\n");k++;break;
                                 case 'D':DestoryAQueue(p);
                                          i=-1;break;
                                 case 'E':DeAQueue(p);
                                          printf("���ӳɹ�!\n");break;
                                 case 'F':foo=APrint;
                                          TraverseAQueue(p,foo,j);break;
                                 case 'G':ClearAQueue(p);
                                          printf("��ճɹ�!\n");break;
                                 case 'H':GetHeadAQueue(p,s,j);break;
                              }
                           }break;

                 }break;
        case 'B':InitLQueue(Q);
                 printf("�ѳ�ʼ��һ��������\n");
                 printf("����ȷ�����������ݵ�����:\n");
                 printf("int:1  double:2  char:3\n");
                 scanf("%d",&j);
                 switch(j)
                 {
                     case 1:printf("��ѡ�����:\n");
                            printf("�п�:A   ��:B   ���:C   ��ͷ����:D\n");
                            printf("��������ӡ:E   �鿴��ͷ:F  ���:G  ���ٲ�����:H\n");
                            for(i=1;i>0;i++)
                           {
                               scanf("%c",&y);
                               switch(y)
                              {
                                 case 'A':IsEmptyLQueue(Q);break;
                                 case 'B':length=LengthLQueue(Q);
                                          printf("��ǰ����Ϊ:%d\n",length);break;
                                 case 'C':printf("������Ҫ��ӵ�����:");
                                          scanf("%d",&a[k]);
                                          r=&a[k];  EnLQueue(Q,r);
                                          printf("��ӳɹ�!\n");k++;break;
                                 case 'D':DeLQueue(Q);
                                          printf("���ӳɹ�!\n");break;
                                 case 'E':foo=LPrint;
                                          TraverseLQueue(Q,foo,j);break;
                                 case 'F':GetHeadLQueue(Q,s,j);break;
                                 case 'G':ClearLQueue(Q);
                                          printf("��ճɹ�!\n");break;
                                 case 'H':DestoryLQueue(Q);
                                          i=-1;break;
                              }
                           }break;
                     case 2:printf("��ѡ�����:\n");
                            printf("�п�:A   ��:B   ���:C   ��ͷ����:D\n");
                            printf("��������ӡ:E   �鿴��ͷ:F  ���:G  ���ٲ�����:H\n");
                            for(i=1;i>0;i++)
                           {
                               scanf("%c",&y);
                               switch(y)
                              {
                                 case 'A':IsEmptyLQueue(Q);break;
                                 case 'B':length=LengthLQueue(Q);
                                          printf("��ǰ����Ϊ:%d\n",length);break;
                                 case 'C':printf("������Ҫ��ӵ�С��:");
                                          scanf("%lf",&b[k]);
                                          r=&b[k];  EnLQueue(Q,r);
                                          printf("��ӳɹ�!\n");k++;break;
                                 case 'D':DeLQueue(Q);
                                          printf("���ӳɹ�!\n");break;
                                 case 'E':foo=LPrint;
                                          TraverseLQueue(Q,foo,j);break;
                                 case 'F':GetHeadLQueue(Q,s,j);break;
                                 case 'G':ClearLQueue(Q);
                                          printf("��ճɹ�!\n");break;
                                 case 'H':DestoryLQueue(Q);
                                          i=-1;break;
                              }
                           }break;
                     case 3:printf("��ѡ�����:\n");
                            printf("�п�:A   ��:B   ���:C   ��ͷ����:D\n");
                            printf("��������ӡ:E   �鿴��ͷ:F  ���:G  ���ٲ�����:H\n");
                            for(i=1;i>0;i++)
                           {
                               scanf("%c",&y);
                               switch(y)
                              {
                                 case 'A':IsEmptyLQueue(Q);break;
                                 case 'B':length=LengthLQueue(Q);
                                          printf("��ǰ����Ϊ:%d\n",length);break;
                                 case 'C':printf("������Ҫ��ӵ��ַ�:");
                                          scanf("%c",&d);
                                          scanf("%c",&c[k]);
                                          r=&c[k];  EnLQueue(Q,r);
                                          printf("��ӳɹ�!\n");k++;break;
                                 case 'D':DeLQueue(Q);
                                          printf("���ӳɹ�!\n");break;
                                 case 'E':foo=LPrint;
                                          TraverseLQueue(Q,foo,j);break;
                                 case 'F':GetHeadLQueue(Q,s,j);break;
                                 case 'G':ClearLQueue(Q);
                                          printf("��ճɹ�!\n");break;
                                 case 'H':DestoryLQueue(Q);
                                          i=-1;break;
                              }
                           }break;

                 }break;
    }
    return 0;
}





































