#include <stdio.h>
#include "sort.h"
#include <time.h>
#include <stdlib.h>
int main()
{
    int a[10000];
    createData(a,10000);
    FILE *fp1=fopen("data1.txt","w");
    if(fp1==NULL) printf("�޷����ļ�\n");
    int i,j=0;
    for(i=0;i<10000;i++)
    {
        fprintf(fp1,"%d  ",a[i]);
        j++;
        if(j%50==0) fprintf(fp1,"\n");
    }
    fclose(fp1);

    FILE *fp2=fopen("data1.txt","r");
    printf("�����У������ĵȺ�!\n");
    for(i=0;fscanf(fp2,"%d",a+i)!=EOF;i++){}
    clock_t s1=clock();
    InsertSort(a,10000);//��������
    clock_t d1=clock()-s1;
 //   printf("����������10000����������ʱ��:%d ms\n",(int)d1);

    for(i=0;fscanf(fp2,"%d",a+i)!=EOF;i++){}
    clock_t s2=clock();
    MergeSort(a,0,9999);//�鲢����
    clock_t d2=clock()-s2;
  //  printf("�鲢������10000����������ʱ��:%d ms\n",(int)d2);

    for(i=0;fscanf(fp2,"%d",a+i)!=EOF;i++){}
    clock_t s3=clock();
    QuickSort1(a,10000);
    clock_t d3=clock()-s3;
 //   printf("�ݹ�������10000����������ʱ��:%d ms\n",(int)d3);

    for(i=0;fscanf(fp2,"%d",a+i)!=EOF;i++){}
    clock_t s4=clock();
    QuickSort2(a,0,9999);
    clock_t d4=clock()-s4;
 //   printf("�ǵݹ�������10000����������ʱ��:%d ms\n",(int)d4);

    //createData(a,10000);
    for(i=0;fscanf(fp2,"%d",a+i)!=EOF;i++){}
    int *c=(int *)malloc(sizeof(int)*10000);
    clock_t s5=clock();
    CountSort(a,c,10000);
    clock_t d5=clock()-s5;
    free(c);
  //  printf("����������10000����������ʱ��:%d ms\n",(int)d5);

    for(i=0;fscanf(fp2,"%d",a+i)!=EOF;i++){}
    fclose(fp2);
    clock_t s6=clock();
    RadixCountSort(a,10000);
    clock_t d6=clock()-s6;
  //  printf("��������������10000����������ʱ��:%d ms\n",(int)d6);



    int arr[50000];
    createData(arr,50000);
    FILE *fp3=fopen("data2.txt","w");
    if(fp3==NULL) printf("�޷����ļ�\n");
    j=0;
    for(i=0;i<50000;i++)
    {
        fprintf(fp3,"%d  ",arr[i]);
        j++;
        if(j%100==0) fprintf(fp3,"\n");
    }
    fclose(fp3);

    FILE *fp4=fopen("data2.txt","r");
    for(i=0;fscanf(fp4,"%d",arr+i)!=EOF;i++){}
    clock_t x1=clock();
    InsertSort(arr,50000);
    clock_t e1=clock()-x1;
 //   printf("����:%d ms\n",(int)e1);

    for(i=0;fscanf(fp4,"%d",arr+i)!=EOF;i++){}
    clock_t x2=clock();
    MergeSort(arr,0,49999);
    clock_t e2=clock()-x2;
  //  printf("�鲢:%d ms\n",(int)e2);

    for(i=0;fscanf(fp4,"%d",arr+i)!=EOF;i++){}
    clock_t x3=clock();
    QuickSort1(arr,50000);
    clock_t e3=clock()-x3;
 //   printf("�ݹ����:%d ms\n",(int)e3);

    for(i=0;fscanf(fp4,"%d",arr+i)!=EOF;i++){}
    clock_t x4=clock();
    QuickSort2(arr,0,49999);
    clock_t e4=clock()-x4;
  //  printf("�ǵݹ����:%d ms\n",(int)e4);

    for(i=0;fscanf(fp4,"%d",arr+i)!=EOF;i++){}
    int *z=(int *)malloc(sizeof(int)*50000);
    clock_t x5=clock();
    CountSort(arr,z,50000);
    clock_t e5=clock()-x5;
    free(z);
  //  printf("��������:%d ms\n",(int)e5);

    for(i=0;fscanf(fp4,"%d",arr+i)!=EOF;i++){}
    fclose(fp4);
    clock_t x6=clock();
    RadixCountSort(arr,50000);
    clock_t e6=clock()-x6;
 //   printf("������������:%d ms\n",(int)e6);




    int q[200000];
    createData(q,200000);
    FILE *f1=fopen("data3.txt","w");
    if(f1==NULL) printf("�޷����ļ�\n");
    j=0;
    for(i=0;i<200000;i++)
    {
        fprintf(f1,"%d  ",q[i]);
        j++;
        if(j%500==0) fprintf(f1,"\n");
    }
    fclose(f1);

    FILE *f2=fopen("data3.txt","r");
    for(i=0;fscanf(f2,"%d",q+i)!=EOF;i++){}
    clock_t n1=clock();
    InsertSort(q,200000);
    clock_t m1=clock()-n1;
 //   printf("����:%d ms\n",(int)m1);

    for(i=0;fscanf(f2,"%d",q+i)!=EOF;i++){}
    clock_t n2=clock();
    MergeSort(q,0,199999);
    clock_t m2=clock()-n2;
  //  printf("�鲢:%d ms\n",(int)m2);

    for(i=0;fscanf(f2,"%d",q+i)!=EOF;i++){}
    clock_t n3=clock();
    QuickSort1(q,200000);
    clock_t m3=clock()-n3;
  //  printf("�ݹ����:%d ms\n",(int)m3);

    for(i=0;fscanf(f2,"%d",q+i)!=EOF;i++){}
    clock_t n4=clock();
    QuickSort2(q,0,199999);
    clock_t m4=clock()-n4;
  //  printf("�ǵݹ����:%d ms\n",(int)m4);

    for(i=0;fscanf(f2,"%d",q+i)!=EOF;i++){}
    int *y=(int *)malloc(sizeof(int)*200000);
    clock_t n5=clock();
    CountSort(q,y,200000);
    clock_t m5=clock()-n5;
 //   printf("��������:%d ms\n",(int)m5);

    for(i=0;fscanf(f2,"%d",q+i)!=EOF;i++){}
    fclose(f2);
    clock_t n6=clock();
    RadixCountSort(q,200000);
    clock_t m6=clock()-n6;
  //  printf("������������:%d ms\n",(int)m6);
   int v[100];
   clock_t r1=clock();
   for(i=0;i<100000;i++)
   {
       createData(v,100);
       InsertSort(v,100);
   }
   clock_t t1=clock()-r1;

   clock_t r2=clock();
   for(i=0;i<100000;i++)
   {
       createData(v,100);
       MergeSort(v,0,99);
   }
   clock_t t2=clock()-r2;


   clock_t r3=clock();
   for(i=0;i<100000;i++)
   {
       createData(v,100);
       QuickSort1(v,100);
   }
   clock_t t3=clock()-r3;

   clock_t r4=clock();
   for(i=0;i<100000;i++)
   {
       createData(v,100);
       QuickSort2(v,0,99);
   }
   clock_t t4=clock()-r4;

   clock_t r5=clock();
   for(i=0;i<100000;i++)
   {
       createData(v,100);
       int *u=(int*)malloc(sizeof(int)*100);
       CountSort(v,u,100);
       free(u);
   }
   clock_t t5=clock()-r5;

   clock_t r6=clock();
   for(i=0;i<100000;i++)
   {
       createData(v,100);
       RadixCountSort(v,100);
   }
   clock_t t6=clock()-r6;



   printf("------------------------------------------------------------------------------------------------\n");
   printf("|        |     ����      |    �鲢   | �ݹ�����  |  �ǵݹ�����   |   ����    | �������� |\n");
   printf("------------------------------------------------------------------------------------------------\n");
   printf("| 10000  |   %d ms      |   %d ms    |    %d ms    |    %d ms      |   %d ms   |  %d ms   |\n",(int)d1,(int)d2,(int)d3,(int)d4,(int)d5,(int)d6);
   printf("------------------------------------------------------------------------------------------------\n");
   printf("| 50000  |   %d ms     |   %d ms   |    %d ms    |    %d ms    |   %d ms   |  %d ms   |\n",(int)e1,(int)e2,(int)e3,(int)e4,(int)e5,(int)e6);
   printf("------------------------------------------------------------------------------------------------\n");
   printf("| 200000 |   %d ms    |   %d ms   |    %d ms   |    %d ms   |   %d ms   |  %d ms   |\n",(int)m1,(int)m2,(int)m3,(int)m4,(int)m5,(int)m6);
   printf("------------------------------------------------------------------------------------------------\n");
   printf("|100*100k|   %d ms    |   %d ms    |   %d ms    |    %d ms   |   %d ms   |   %d ms  |\n",(int)t1,(int)t2,(int)t3,(int)t4,(int)t5,(int)t6);
   printf("-------------------------------------------------------------------------------------------------\n");
    return 0;
}
