#include <stdio.h>
#include "sort.h"
#include<stdlib.h>

void InsertSort(int a[],int n)    //��������
{
    int i,j,temp;
    for(i=1;i<n;i++)
    {
        if(a[i-1]>a[i])
        {
            temp=a[i];
            a[i]=a[i-1];
            j=i-1;
            while(j>0&&a[j-1]>temp)
            {
                a[j]=a[j-1];
                j--;
            }
            a[j]=temp;
        }
    }
}


void merge(int *a,int first,int mid,int last)    //�ϲ�
{
    int i,index,first1,first2,last1,last2;
    int *temp=(int *)malloc(sizeof(int)*(last-first+1));
    index=0;
    first1=first;
    last1=mid;
    first2=mid+1;
    last2=last;
    while((first1<=last1)&&(first2<=last2))
    {
        if(a[first1]<a[first2])
        {
            temp[index++]=a[first1++];
        }else{
           temp[index++]=a[first2++];
        }
    }
    while(first1<=last1)
    {
        temp[index++]=a[first1++];
    }
    while(first2<=last2)
    {
        temp[index++]=a[first2++];
    }
    for(i=0;i<(last-first+1);i++)
    {
        a[first+i]=temp[i];
    }
    free(temp);
}


void MergeSort(int *a,int first,int last) //�ݹ�+�ϲ�
{
    int mid=0;
    if(first<last)
    {
        mid=(first+last)/2;
        MergeSort(a,first,mid);
        MergeSort(a,mid+1,last);
        merge(a,first,mid,last);
    }
}


void QuickSort1(int *a,int n)  //����(�ݹ��)
{
    int i,j,mid,temp;
    if(n<2) return;
    mid=a[n/2];
    for(i=0,j=n-1;;i++,j--)
    {
        while(a[i]<mid) i++;
        while(a[j]>mid) j--;
        if(i>=j) break;
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
    }
    QuickSort1(a,i);
    QuickSort1(a+i,n-i);
}


void QuickSort2(int *a,int first,int last) //����(�ǵݹ��)
{
   int i,j,temp,top,goal;
   i=first;
   j=last;
   struct node Stack[200];
   top=0;
   Stack[top].first=first;
   Stack[top].last=last;
 while(top>-1)
 {
    i=first=Stack[top].first;
    j=last=Stack[top].last;
    top--;
    goal=a[first];
    while(i<j)
    {
         while((i<j) && (a[j]>=goal))
         {j--;}
        if(i < j)
        {
          temp = a[i];a[i] = a[j];a[j] = temp;
          i++;
        }
        while((i<j) && (a[i]<=goal))
        {i++;}
       if(i < j)
       {
         temp = a[i];a[i] = a[j];a[j] = temp;
         j--;
       }
     }
    if(first<i-1)
    {
        top++;
        Stack[top].first=first;
        Stack[top].last= i-1;
    }
    if(last>i+1)
    {
        top++;
        Stack[top].first=i+1;
        Stack[top].last=last;
    }
 }
}


void CountSort(int *a,int *sorted,int n) //��������
{
    int *b=(int *)malloc(sizeof(int)*10000);
    int i,num;
    for(i=0;i<10000;i++)
    {
        b[i]=0;
    }
    for(i=0;i<n;i++)    //��¼����a[i]ֵ�ĸ���
    {
        num=a[i];
        b[num]++;
    }
    for(i=1;i<10000;i++)    //����С��a[i]ֵ�ĸ���
    {
        b[i]=b[i]+b[i-1];
    }
    for(i=n-1;i>=0;i--)
    {
        num=a[i];
        sorted[b[num]-1]=num;
        b[num]--;
    }
    free(b);
}


int GetDigit(int a)
{
    if(a==0) return 1;
    int k=0;
    while(a!=0)
    {
        k++;
        a=a/10;
    }
    return k;
}


void RadixCountSort(int *a,int n) //������������
{
    int i,j,max=a[0];
    int *bucket=(int *)malloc(sizeof(int)*n);
    int count[10];
    for(i=1;i<n;i++)
    {
        if(a[i]>max)
            max=a[i];
    }
    int maxdigit=GetDigit(max);
    int m=1,num;
    for(i=1;i<=maxdigit;i++)
    {
        for(j=0;j<10;j++)
        {
            count[j]=0;
        }
        for(j=0;j<n;j++)
        {
            num=a[j]/m%10;
            count[num]++;
        }
        for(j=1;j<10;j++)
        {
            count[j]=count[j]+count[j-1];
        }
        for(j=n-1;j>=0;j--)
        {
            num=a[j]/m%10;
            bucket[count[num]-1]=a[j];
            count[num]--;
        }
        for(j=0;j<n;j++)
        {
            a[j]=bucket[j];
        }
        m=m*10;
    }
    free(bucket);
}

void createData(int *a,int n)  //����СΪn�����������ֵ
{
    int i;
    for(i=0;i<n;i++)
    {
        a[i]=rand()%10000;
    }
}
