#include <stdio.h>
void colorSort(int *a,int n)
{
    int i=0,left,right,temp;
    left=-1;
    right=n;
    while(i<right)
    {
        if(a[i]==0)
        {
            left++;
            if(i!=left)
           {
               temp=a[i];
            a[i]=a[left];
            a[left]=temp;
           }
           i++;
        }else if(a[i]==2)
        {
           right=right-1;
           if(i!=right)
           {
               temp=a[i];
            a[i]=a[right];
            a[right]=temp;
           }
        }else
        {
            i++;
        }
    }

}


void QuickSort(int *a,int n)
{
    int i,j,mid,temp;
    if(n<2) return;
    mid=a[n/2];
    for(i=0,j=n-1;;i++,j--)
    {
        while(a[i]<mid) i++;
        while(a[j]>mid) j--;
        if(i>=j) break;
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
    }
    QuickSort(a,i);
    QuickSort(a+i,n-i);
}

int main()
{
    //void colorSort(int *a,int n);
    int a[]={1,0,2,1,2,0,1,1,2,2,0,1,2,2,1,0,1};
    int i,n=sizeof(a)/sizeof(a[0]);
    for(i=0;i<n;i++)
    {
        printf("%d  ",a[i]);
    }
    printf("\n\n");

    colorSort(a,n);

    for(i=0;i<n;i++)
    {
        printf("%d  ",a[i]);
    }

    printf("\n\n");
    int b[]={1,3,12,34,63,98,123,247,47,7,121,233,213,2,};
    n=sizeof(b)/sizeof(a[0]);
    printf("ԭ�����е���Ϊ:\n");
    for(i=0;i<n;i++)
        printf("%d  ",b[i]);
    printf("\n");
    QuickSort(b,n);
    int k;
    printf("ҪѰ�ҵ�k�����,������k��ֵ:");
    scanf("%d",&k);
    printf("��%d�����Ϊ:%d\n",k,b[n-k]);

return 0;

}
